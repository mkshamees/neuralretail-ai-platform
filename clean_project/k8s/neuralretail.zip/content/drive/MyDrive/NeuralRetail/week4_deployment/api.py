
from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import pandas as pd

app = FastAPI(title="NeuralRetail ML API", version="1.0")

# ---------------- LOAD MODEL ----------------
model_path = "/content/drive/MyDrive/NeuralRetail/models/churn_model.pkl"
model = joblib.load(model_path)

# ---------------- REQUEST SCHEMA ----------------
class ChurnRequest(BaseModel):
    recency: float
    frequency: float
    monetary: float

# ---------------- HEALTH CHECK ----------------
@app.get("/health")
def health():
    return {"status": "API running"}

# ---------------- PREDICT CHURN ----------------
@app.post("/predict/churn")
def predict_churn(data: ChurnRequest):

    input_data = [[
        data.recency,
        data.frequency,
        data.monetary
    ]]

    prediction = model.predict(input_data)[0]

    return {
        "churn_prediction": int(prediction),
        "label": "High Risk" if prediction == 1 else "Low Risk"
    }
